package com.support;

public class SupportRepresentative extends SupportHandler {
	   public void handleRequest(String request) {
	        if (request.equalsIgnoreCase("basic")) {
	            System.out.println("Support Representative is handling the request.");
	        } else if (nextHandler != null) {
	            nextHandler.handleRequest(request);
	        }
	    }

}
