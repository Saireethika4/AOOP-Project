package com.support;

public class Director extends SupportHandler{
	   public void handleRequest(String request) {
	        if (request.equalsIgnoreCase("complex")) {
	            System.out.println("Director is handling the request.");
	        } else {
	            System.out.println("Request cannot be handled.");
	        }
	    }

}
