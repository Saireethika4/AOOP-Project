package com.support;

public class CustomerSupportSystem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 SupportHandler representative = new SupportRepresentative();
	        SupportHandler manager = new Manager();
	        SupportHandler director = new Director();
	        representative.setNextHandler(manager);
	        manager.setNextHandler(director);
	        
	        representative.handleRequest("basic");       
	        representative.handleRequest("intermediate"); 
	        representative.handleRequest("complex");      
	        representative.handleRequest("unknown");     
	    


	}

}
