package com.support;

public class Manager extends SupportHandler{
	  public void handleRequest(String request) {
	        if (request.equalsIgnoreCase("intermediate")) {
	            System.out.println("Manager is handling the request.");
	        } else if (nextHandler != null) {
	            nextHandler.handleRequest(request);
	        }
	    }

}
