package com.support;

import org.junit.Before;
import org.junit.Test;

public class SupportHandlerTest {
    private SupportHandler representative;
    private SupportHandler manager;
    private SupportHandler director;

    @Before
    public void setUp() {
        representative = new SupportRepresentative();
        manager = new Manager();
        director = new Director();

        representative.setNextHandler(manager);
        manager.setNextHandler(director);
    }

    @Test
    public void testBasicRequestHandledByRepresentative() {
        representative.handleRequest("basic");
    }

    @Test
    public void testIntermediateRequestHandledByManager() {
        representative.handleRequest("intermediate");
    }

    @Test
    public void testComplexRequestHandledByDirector() {
        representative.handleRequest("complex");
    }

    @Test
    public void testUnknownRequestHandledByNone() {
        representative.handleRequest("unknown");
    }
}